const nombre = document.getElementById("nombre");
const apellido = document.getElementById("apellido");   
const enviar = document.getElementsById("enviar");
const nombreTarjeta = document.getElementById("nombreTarjeta");
const apellidoTarjeta = document.getElementById("apellidoTarjeta");

// let nombreUri = encodeURIComponent(nombre.value);
// let apellidoUri = encodeURIComponent(apellido.value);

// window.location.href = "tarjeta.html?nombre=" + nombreUri + "&apellido=" +
//     apellidoUri;

// enviar.addEventListener("click", () => {
//     let nombreUri = encodeURIComponent(nombre.value);
//     let apellidoUri = encodeURIComponent(apellido.value);

//     window.location.href = "tarjeta.html?nombre=" + nombreUri + "&apellido=" +
//         apellidoUri;
// });

function enviar() {
    let nombreUri = encodeURIComponent(nombre.value);
    let apellidoUri = encodeURIComponent(apellido.value);

    window.location.href = "tarjeta.html?nombre=" + nombreUri + "&apellido=" +
        apellidoUri;
}

let parametros = new URLSearchParams(window.location.search);
nombreTarjeta.textContent = decodeURIComponent(parametros.get('nombreUri'));
apellidoTarjeta.textContent = decodeURIComponent(parametros.get('apellidoUri'));